# threep

**threep** — a simple Web-GUI powered "desktop calculator" made using Haskell and [threepenny-gui](https://hackage.haskell.org/package/threepenny-gui) toolkit. Projects intended to be an example of how to use Threepenny-GUI.

### Howto

```shell
$ cabal new-build
$ cabal new-run threep
```
